import { DynamoDBClient, UpdateItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1",
});
const TABLE_NAME = 'TaskItems';

export const handler = async (event) => {
    try {
        console.log("Received input: ", event);

        // Parse the request body
        const { body } = event;
        const parsedBody = JSON.parse(body);

        // Extract taskId
        const { taskId } = parsedBody;

        // Check if taskId is provided or not
        if (!taskId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Task ID is required field' }),
            };
        }

        // Define parameters for DynamoDB to Update status
        const params = {
            TableName: TABLE_NAME,
            Key: {
                taskId: { S: taskId },
            },
            UpdateExpression: "SET #status = :status",
            ExpressionAttributeNames: {
                "#status": "status"
            },
            ExpressionAttributeValues: {
                ":status": { S: "Completed" }
            }
        };

        // Execute Update operation on DB
        await dynamoDBClient.send(new UpdateItemCommand(params));

        console.log("Task status updated to Completed successfully!");

        // Return success response
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Task status updated to Completed successfully!' }),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error response
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Could not update the task status to complete', error: error.message }),
        };
    }
};
