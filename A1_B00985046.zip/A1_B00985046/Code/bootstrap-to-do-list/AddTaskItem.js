import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", 
});
const TABLE_NAME = 'TaskItems';

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);

        // Parse the request body to add details in DB
          const { task } = event.body;


        // Check if task is missing in input
        if (!task) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Task is required field' }),
            };
        }

        // Generate a unique task ID for partition key
        const taskId = uuidv4();

        // Define parameters for DynamoDB PutItem operation
        const params = {
            TableName: TABLE_NAME,
            Item: {
                taskId: { S: taskId },
                task: { S: task },
                status: { S: 'Active' }
            },
        };

        // Execute PutItem operation in DB
        await dynamoDBClient.send(new PutItemCommand(params));

        console.log("Task saved successfully in DB!");

        // Return success response once done
        return {
            statusCode: 200,
            body: JSON.stringify({ taskId: taskId, message: 'Task saved successfully in DB!' }),
        };
    } catch (error) {
        console.error("Error occurred while saving in DB and error is: ", error);
        // Return error response
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Could not save the task due to', error: error.message }),
        };
    }
};

// Function to generate UUID for partition key
function uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}
