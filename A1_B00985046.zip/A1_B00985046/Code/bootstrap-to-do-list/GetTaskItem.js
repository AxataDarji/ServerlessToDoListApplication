import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";

const dynamoDBClient = new DynamoDBClient({
    region: "us-east-1", 
});
const TABLE_NAME = 'TaskItems';

export const handler = async (event) => {
    try {
        console.log("Input is: ", event);

        // Retrieve all items from DynamoDB
        const params = {
            TableName: TABLE_NAME,
        };

        const data = await dynamoDBClient.send(new ScanCommand(params));
        
        // Simplify the response
        const items = data.Items.map(item => {
            return {
                taskId: item.taskId.S,
                task: item.task.S,
                status: item.status.S
            };
        });

        // Return success response 
        return {
            statusCode: 200,
            body: JSON.stringify(items),
        };
    } catch (error) {
        console.error("Error occurred which is: ", error);
        // Return error
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Could not retrieve items from DB', error: error.message }),
        };
    }
};
