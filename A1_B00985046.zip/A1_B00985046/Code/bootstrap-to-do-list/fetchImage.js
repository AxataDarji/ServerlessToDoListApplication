import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const s3Client = new S3Client({
    region: "us-east-1", // Change to your desired region
});

export const handler = async () => {
    const objectUrl = "https://taskmanagementsystem.s3.amazonaws.com/Task_Image.jpg";

    // Extract the S3 bucket name and key from the object URL
    const { bucketName, key } = extractBucketAndKey(objectUrl);
    
    try {
        // Get the image object from S3
        const response = await s3Client.send(new GetObjectCommand({ Bucket: bucketName, Key: key }));

        // Get the image data as a buffer
        const imageDataBuffer = await streamToBuffer(response.Body);

        // Encode the buffer to base64
        const imageDataBase64 = imageDataBuffer.toString('base64');

        return {
            statusCode: 200,
            body: imageDataBase64,
            isBase64Encoded: true,
            headers: {
                'Content-Type': 'image/jpeg' // JPG file content type
            }
        };
    } catch (error) {
        console.error("Error fetching image from S3:", error);
        return {
            statusCode: 500,
            body: 'Error fetching image from S3'
        };
    }
};

function extractBucketAndKey(objectUrl) {
    // Assuming object URL format: https://s3.amazonaws.com/bucket_name/key
    const url = new URL(objectUrl);
    const bucketName = url.hostname.split('.')[0];
    const key = url.pathname.slice(1); // Remove the leading slash
    return { bucketName, key };
}

async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}
